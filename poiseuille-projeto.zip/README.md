# Projeto Poiseuille

Este repositório contém o caso simulado no OpenFOAM com sua solução analítica.
