# Código analítico da solução de Poiseuille
